import java.util.*;
import java.io.*;
public class Oblig2 {

  static Task [] tasks;
  LinkedList<Task> predecessors = new LinkedList<Task>();

  public static void main(String[] args) throws Exception {
    Oblig2 makeP = new Oblig2();
    makeP.readFile(args[0]);
    Project p = makeP.makeProject();
    //makeP.print(); //printer oversikt over taskene, og deres inedges og outedges

    p.calculateTime();
    p.printProject();

  }


      public void set() {
        for(int i = 1; i < tasks.length; i++) {
          for(Task t : predecessors) {
            if(i == t.getId()) {
              t.setDetails(tasks[i]);
            }
          }
        }
      }

      public void readFile(String file) throws FileNotFoundException {
        Scanner scan = new Scanner(new File(file));
        int countTask = scan.nextInt();
        tasks = new Task[countTask+1];

        int idT = 1; int timeT = 0; int mpT = 0; String nameT = " ";
        String linje = scan.nextLine(); //leser den tomme linjen

        while(scan.hasNextLine()) {
          try {
            idT = scan.nextInt();
            nameT = scan.next();
            timeT = scan.nextInt();
            mpT = scan.nextInt();
          } catch(NoSuchElementException e) {};

          if(tasks[idT] == null) {
            tasks[idT] = new Task(idT, nameT, timeT, mpT);
          }

          while(scan.hasNextInt()) {
            int predecessorID = scan.nextInt();

            if (predecessorID != 0)  {
              Task t = new Task(predecessorID);
              predecessors.add(t);

              tasks[idT].addDependencies(t);
            }
            if(predecessorID == 0) {
              break;
            }
          }

        }

        //legger til inEdges med fullInformasjon (navn, tid, staff)
        set();

        //legger til OutEdges
        for(int i = 1; i < tasks.length; i++) {
          for(Task t : tasks[i].getDependencies()) {
            tasks[t.getId()].addOutEdges(tasks[i]);
          }
        }

      }

      public Project makeProject() {
        return new Project(tasks);
      }

      public void print()  {
        for(int i = 1; i < tasks.length; i++) {
          System.out.println("_____________________________");
          System.out.println("TASK: " + tasks[i]);

          System.out.println("**IN EDGES**");
          for(Task t1 : tasks[i].getDependencies()) {
            System.out.println(t1.toString() + "\n");
          }
          System.out.println("**OUT EDGES**");
          for(Task t2 : tasks[i].getOutEdges()) {
            System.out.println(t2.toString() + "\n");
          }
        }
      }

      public static Task[] getTasks() {
        return tasks;
      }

} //enf of class
