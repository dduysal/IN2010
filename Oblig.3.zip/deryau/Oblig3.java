import java.util.Random;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;

public class Oblig3 {
  public static void main(String[] args) {
    int n = Integer.parseInt(args[1]);
    Algorithms algo = new Algorithms();
    Oblig3 main = new Oblig3();
    //TEST-PROGRAM
    if(args[0].equals("Selection-Sort")) {
      main.testSelection(n, algo);
    }
    else if(args[0].equals("Heap-Sort")) {
      main.testHeap(n, algo);
    }
    else if(args[0].equals("Merge-Sort")) {
      main.testMerge(n, algo);
    }
    else if(args[0].equals("Array-Sort")) {
      main.testArraysort(n, algo);
    }
    else {
      System.out.println("Ugyldig input");
    }
  }

/**********************************************************************************************************/
  //Stigende, Fallende, Random, Arraysort
  public void testSelection(int n, Algorithms algo) {

    /*long t = System.nanoTime(); //nanosekunder
    // din kode her*/

    //Random ikke unik
    System.out.println("************-Random-**************");
    Random r = new Random();
    int[] random1 = new int[n];
    int[] random2 = new int[n];

    //Unik-Random
    ArrayList<Integer> unikRan = new ArrayList<Integer>();
    for (int i = 0; i < n; i++) {
      unikRan.add(i);
    }
    Collections.shuffle(unikRan);

    int[] sorted1 = new int[n];
    int[] sorted2 = new int[n];

    for(int i = 0; i < n; i++) {
      sorted1[i] = i; //unik
      sorted2[i] = r.nextInt(n); //ikke unik
      random1[i] = unikRan.get(i); //unik
      random2[i] = r.nextInt(n); //ikke unik
    }

    System.out.println("Selection Sort  Unik:" + Arrays.toString(algo.selectionSort(random1)) + "\n");
    System.out.println("Selection Sort ikke-Unik:" + Arrays.toString(algo.selectionSort(random2)) + "\n");

    System.out.println("*************-Sorted-**************");
    System.out.println("Selection Sort Unik:" + Arrays.toString(algo.selectionSort(sorted1)) + "\n");
    System.out.println("Selection Sort Ikke Unik:" + Arrays.toString(algo.selectionSort(sorted2)) + "\n");


    //fallende (10 og nedover)
    System.out.println("************-Revertsert-***********");
    int[] reversert1 = new int[n];
    int[] reversert2 = new int[n];

    for(int i = n -1; i >= 0; i--) {
      reversert1[i] = i; //unik
      reversert2[i] = r.nextInt(n); //ikke unik
    }

    System.out.println("Selection Sort: Unik " + Arrays.toString(algo.selectionSort(reversert1)) + "\n");
    System.out.println("Selection Sort: Ikke Unik" + Arrays.toString(algo.selectionSort(reversert2)) + "\n");

    /*double tid = ( System.nanoTime() - t ) / 1000000.0; //millisekunder
    System.out.println("Kjøretid: " + tid);*/
  }


/**********************************************************************************************************/
  //Stigende, Fallende, Random, Array sort
  public void testHeap(int n, Algorithms algo) {
    long t = System.nanoTime(); //nanosekunder
    // din kode her*/

    Random r = new Random();
    int[] random1 = new int[n];
    int[] random2 = new int[n];

    //Unik-Random
    ArrayList<Integer> unikRan = new ArrayList<Integer>();
    for (int i = 0; i < n; i++) {
      unikRan.add(i);
    }
    Collections.shuffle(unikRan);

    int[] sorted1 = new int[n];
    int[] sorted2 = new int[n];

    for(int i = 0; i < n; i++) {
      sorted1[i] = i; //unik
      sorted2[i] = r.nextInt(n); //ikke unik
      random1[i] = unikRan.get(i); //unik
      random2[i] = r.nextInt(n); //ikke unik
    }

    System.out.println("************-Random-**************");
    //random unik
    System.out.println("Heap Sort Unik:" + Arrays.toString(algo.heapSort(random1)) + "\n");
    //random ikke unik
    System.out.println("Heap Sort Ikke Unik:" + Arrays.toString(algo.heapSort(random2)) + "\n");

    System.out.println("*************-Sorted-**************");
    //sorted unik
    System.out.println("Heap Sort Unik:" + Arrays.toString(algo.heapSort(sorted1)) + "\n");
    //sorted ikke unik
    System.out.println("Heap Sort Ikke Unik:" + Arrays.toString(algo.heapSort(sorted2)) + "\n");


    //fallende (10 og nedover)
    System.out.println("************-Revertsert-***********");
    int[] reversert1 = new int[n];
    int[] reversert2 = new int[n];

    for(int i = n -1; i >= 0; i--) {
      reversert1[i] = i; //unik
      reversert2[i] = r.nextInt(n); //ikke unik
    }

    //reversert unik
    System.out.println("Heap Sort: Unik " + Arrays.toString(algo.heapSort(reversert1)) + "\n");
    //reversert ikke unik
    System.out.println("Heap Sort: Ikke Unik" + Arrays.toString(algo.heapSort(reversert2)) + "\n");

    /*double tid = ( System.nanoTime() - t ) / 1000000.0; //millisekunder
    System.out.println("Kjøretid: " + tid);*/
  }

/**********************************************************************************************************/
  //Stigende, Fallende, Random, Array sort
  public void testMerge(int n, Algorithms algo) {
    System.out.println("******** MERGE-SORT **************");
    long t = System.nanoTime(); //nanosekunder
    Random r = new Random();
    int[] random1 = new int[n];
    int[] random2 = new int[n];

    //Unik-Random
    ArrayList<Integer> unikRan = new ArrayList<Integer>();
    for (int i = 0; i < n; i++) {
      unikRan.add(i);
    }
    Collections.shuffle(unikRan);

    int[] sorted1 = new int[n];
    int[] sorted2 = new int[n];

    for(int i = 0; i < n; i++) {
      sorted1[i] = i; //unik
      sorted2[i] = r.nextInt(n); //ikke unik
      random1[i] = unikRan.get(i); //unik
      random2[i] = r.nextInt(n); //ikke unik
    }


    System.out.println("************-Random-**************");
    //random unik
    System.out.println("Hver iterasjon: ");
    System.out.println();
    System.out.println("Merge Sort Unik :" + Arrays.toString(algo.mergeSort(random1, 0, random1.length-1)));

    //random ikke unik
    System.out.println("Hver iterasjon: ");
    System.out.println();
    System.out.println("Merge Sort: Ikke Unik" + Arrays.toString(algo.mergeSort(random2, 0, random2.length-1)));


    System.out.println("*************-Sorted-**************");
    //sorted unik
    System.out.println("Hver iterasjon: ");
    System.out.println();
    System.out.println("Merge Sort Unik :" + Arrays.toString(algo.mergeSort(random1, 0, random1.length-1)));

    //sorted ikke unik
    System.out.println("Hver iterasjon: ");
    System.out.println();
    System.out.println("Merge Sort: Ikke Unik" + Arrays.toString(algo.mergeSort(sorted2, 0, sorted2.length-1)));


    //fallende (10 og nedover)
    System.out.println("************-Revertsert-***********");
    int[] reversert1 = new int[n];
    int[] reversert2 = new int[n];

    for(int i = n -1; i >= 0; i--) {
      reversert1[i] = i; //unik
      reversert2[i] = r.nextInt(n); //ikke unik
    }

    //sorted unik
    System.out.println("Hver iterasjon: ");
    System.out.println();
    System.out.println("Merge Sort Unik :" + Arrays.toString(algo.mergeSort(reversert1, 0, reversert1.length-1)));
    //sorted ikke unik
    System.out.println("Hver iterasjon: ");
    System.out.println();
    System.out.println("Merge Sort: Ikke Unik" + Arrays.toString(algo.mergeSort(reversert2, 0, reversert2.length-1)));

  }


  public void testArraysort(int n, Algorithms algo) {
    long t = System.nanoTime(); //nanosekunder
    System.out.println("******** ARRAY-SORT **************");
    Random r = new Random();
    int[] random1 = new int[n];
    int[] random2 = new int[n];

    //Unik-Random
    ArrayList<Integer> unikRan = new ArrayList<Integer>();
    for (int i = 0; i < n; i++) {
      unikRan.add(i);
    }
    Collections.shuffle(unikRan);

    int[] sorted1 = new int[n];
    int[] sorted2 = new int[n];

    for(int i = 0; i < n; i++) {
      sorted1[i] = i; //unik
      sorted2[i] = r.nextInt(n); //ikke unik
      random1[i] = unikRan.get(i); //unik
      random2[i] = r.nextInt(n); //ikke unik
    }

    System.out.println("************-Random-**************");
    //random unik
    Arrays.sort(random1, 0, n);
    System.out.println("Array-Sort Unik" + Arrays.toString(random1) + "\n");

    //random ikke unik
    Arrays.sort(random2, 0, n);
    System.out.println("Array-Sort Ikke-Unik" + Arrays.toString(random2) + "\n");


    System.out.println("*************-Sorted-**************");
    //sorted unik
    Arrays.sort(sorted1, 0, n);
    System.out.println("Array-Sort Unik" + Arrays.toString(sorted1) + "\n");

    //sorted ikke unik
    Arrays.sort(sorted2, 0, n);
    System.out.println("Array-Sort Ikke-Unik" + Arrays.toString(sorted2) + "\n");


    //fallende (10 og nedover)
    System.out.println("************-Revertsert-***********");
    int[] reversert1 = new int[n];
    int[] reversert2 = new int[n];

    for(int i = n -1; i >= 0; i--) {
      reversert1[i] = i; //unik
      reversert2[i] = r.nextInt(n); //ikke unik
    }

    //reversert unik
    Arrays.sort(reversert1, 0, n);
    System.out.println("Array-Sort Unik" + Arrays.toString(reversert1) + "\n");

    //reversert ikke unik
    Arrays.sort(reversert2, 0, n);
    System.out.println("Array-Sort Ikke Unik" + Arrays.toString(reversert2) + "\n");

    double tid = ( System.nanoTime() - t ) / 1000000.0; //millisekunder
    System.out.println("Kjøretid: " + tid);

  }

}
