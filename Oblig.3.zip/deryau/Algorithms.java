import java.util.Arrays;

public class Algorithms {

  public int[] selectionSort(int [] list) {
    System.out.println("Hver iterasjon: ");

    for(int i = 0; i < list.length-1; i++) {
      int min = i;
      for(int j = i+1; j < list.length; j++) {
        if(list[j] < list[min]) {
          min = j;
        }
      }
      if(i != min) {
        int temp = list[i];
        list[i] = list[min];
        list[min] = temp;
      }
      System.out.println(Arrays.toString(list)); //printer ut hver iterasjon
    }
    System.out.println();
    return list;
  }



  //heapSort
  public int[] heapSort(int [] list) {
    System.out.println("Hver iterasjon: ");

    //max heap
    for(int i = (list.length / 2) - 1; i >= 0; i--){
      heapify(list, list.length, i);
    }

    //heap sort
    for(int i = list.length - 1; i >= 0; i--) {
      int temp = list[0];
      list[0] = list[i];
      list[i] = temp;
      System.out.println(Arrays.toString(list)); //printer ut hver iterasjon
      heapify(list, i, 0);
    }
    System.out.println();
    return list;
  }

  public void heapify(int [] list, int length, int i) {
    int largest = i;
    int left = (2 * i) + 1;
    int right = (2 * i) + 2;

    if(left < length && list[left] > list[largest]) {
      largest = left;
    }

    if(right < length && list[right] > list[largest]) {
      largest = right;
    }

    if(largest != i) {
      int swap = list[i];
      list[i] = list[largest];
      list[largest] = swap;

      heapify(list, length, largest);
    }
  }



  //merge-sort
  public int [] merge(int [] array, int start, int mid, int end) {
    int s1 = mid - start + 1;
    int s2 = end - mid;
    int [] sub1 = new int[s1];
    int [] sub2 = new int[s2];

    for(int t = 0; t < s1; t++) {
      sub1[t] = array[start + t];
    }

    for(int p = 0; p < s2; p++) {
      sub2[p] = array[mid + 1 + p];
    }

    int i = 0;
    int j = 0;
    int k = start;

    while(i < s1 && j < s2) {
      if(sub1[i] <= sub2[j]) {
        array[k] = sub1[i];
        i++;
        System.out.println("First " + Arrays.toString(sub1)); //printer ut iterajon for sub1[]
      }
      else {
        array[k] = sub2[j];
        j++;
        System.out.println("Second " + Arrays.toString(sub2)); //printer ut iterasjon for sub2[]
      }
      k++;
    }

    while(i < s1) {
      array[k] = sub1[i];
      i++;
      k++;
      System.out.println("First " + Arrays.toString(sub1));//printer ut iterajon for sub1[]
    }

    while(j < s2) {
      array[k] = sub2[j];
      j++;
      k++;
      System.out.println("Second " + Arrays.toString(sub2)); //printer ut iterasjon for sub2[]
    }
    return array;
  }


  public int [] mergeSort(int[] array, int start, int end) {
    if(start >= end) {
      return array;
    } else {
      int mid = (start + end)/ 2;
      mergeSort(array, start, mid);
      mergeSort(array, mid+1, end);
      return merge(array, start, mid, end);
    }
  }

} //end of clas
