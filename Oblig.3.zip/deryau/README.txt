Java-filen inneholder java-implementasjoner av selection sort (inplace), heap sort (inplace) og merge sort, basert på pensumboka:
Algorithm Design and Application (Goodrich, Michael T.) og enkelte videor fra youtube for forståelse av algoritmene.

Kompileres: $ javac *.java
Kjøring: $ java Oblig3 Selection-Sort 10

Da printes hver iterajson av hver algoritmene sammen med input typene (ikke-unik tilfeldig, ikke-unik sortert, ikke-unik fallende, unik tilfeldig, unik sortert, unik fallende). Men da jeg testet hastigheten så kommenterte jeg bort den delen av metoden som ikke skulle testes. For eksempel metoden selectionSort() ikke-unik som input, så kommenterte jeg bort de andre inputtypene som er i samme metode. 


