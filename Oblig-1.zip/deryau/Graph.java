import java.util.List;
import java.util.LinkedList;

class Graph {
	private Node[] nodes;

	public Graph(Node[] nodes) {
		this.nodes = nodes;
	}

	public void printNeighbors() {
		for (Node n1 : nodes) {
			String s = n1.toString() + ": ";
			for (Node n2 : n1.getNeighbors()) {
				s += n2.toString() + " ";
			}
			System.out.println(s.substring(0, s.length() - 1));
		}
	}

	private static Graph buildExampleGraph() {
		// ukeoppgave
		Node[] nodes = new Node[7];
		for (int i = 0; i < nodes.length; i++) {
			nodes[i] = new Node(i);
		}
		nodes[0].addNeighbor(nodes[1]);
		nodes[0].addNeighbor(nodes[2]);
		nodes[1].addNeighbor(nodes[2]);
		nodes[2].addNeighbor(nodes[3]);
		nodes[2].addNeighbor(nodes[5]);
		nodes[3].addNeighbor(nodes[4]);
		nodes[4].addNeighbor(nodes[5]);
		nodes[5].addNeighbor(nodes[6]);
		return new Graph(nodes);
	}

	private static Graph buildRandomSparseGraph(int numberofV, long seed) {
		// seed brukes av java.util.Random for å generere samme sekvens for samme frø
		// (seed) og numberofV
		java.util.Random tilf = new java.util.Random(seed);
		int tilfeldig1 = 0, tilfeldig2 = 0;
		Node[] nodes = new Node[numberofV];

		for (int i = 0; i < numberofV; i++) {
			nodes[i] = new Node(i);
		}

		for (int i = 0; i < numberofV; i++) {
			tilfeldig1 = tilf.nextInt(numberofV);
			tilfeldig2 = tilf.nextInt(numberofV);
			if (tilfeldig1 != tilfeldig2)
			nodes[tilfeldig1].addNeighbor(nodes[tilfeldig2]);
		}
		return new Graph(nodes);
	}

	private static Graph buildRandomDenseGraph(int numberofV, long seed) {
		java.util.Random tilf = new java.util.Random(seed);
		int tilfeldig1 = 0, tilfeldig2 = 0;
		Node[] nodes = new Node[numberofV];

		for (int i = 0; i < numberofV; i++) {
			nodes[i] = new Node(i);
		}

		for (int i = 0; i < numberofV * numberofV; i++) {
			tilfeldig1 = tilf.nextInt(numberofV);
			tilfeldig2 = tilf.nextInt(numberofV);
			if (tilfeldig1 != tilfeldig2)
			nodes[tilfeldig1].addNeighbor(nodes[tilfeldig2]);
		}
		return new Graph(nodes);
	}

	private static Graph buildRandomDirGraph(int numberofV, long seed) {
		java.util.Random tilf = new java.util.Random(seed);
		int tilfeldig1 = 0, tilfeldig2 = 0;
		Node[] nodes = new Node[numberofV];

		for (int i = 0; i < numberofV; i++) {
			nodes[i] = new Node(i);
		}

		for (int i = 0; i < 2 * numberofV; i++) {
			tilfeldig1 = tilf.nextInt(numberofV);
			tilfeldig2 = tilf.nextInt(numberofV);
			if (tilfeldig1 != tilfeldig2)
			nodes[tilfeldig1].addSuccessor(nodes[tilfeldig2]);
		}
		return new Graph(nodes);
	}

	//besøker alle nodene i komponenten til s
	public void DFS(Node s) {
		s.visit();
		for(int i = 0; i < nodes.length; i++) {
			//if(nodes[i].getLabel() == s.getLabel()) { //forsikre meg at node s er med node-arrayen
				for(Node n : s.getNeighbors()) {
					if(n.isVisited() == false) {
						DFS(n);
					}
				}
			//}
		}
	}

	//går gjennom alle komponenter i grafen
	public void DFSFull() {
		for(int i = 0; i < nodes.length; i++) {
			if(nodes[i].isVisited() == false) {
				DFS(nodes[i]);
			}
		}
	}

	// Oppgave 1A
	public int numberOfComponents() {
		int teller = 0;
		for(int i = 0; i < nodes.length; i++) {
			nodes[i].unvisit();
		}
		for(int j = 0; j < nodes.length; j++) {
			if(nodes[j].isVisited() == false) {
				DFS(nodes[j]);
				teller++;
			}
		}
		return teller;
	}

	//Oppgave 1B
	public Graph transformDirToUndir() {
		Node [] undir = new Node[nodes.length];
		//HashMap<Node, Node> map = new HashMap<Node,Node>();
		for(int v= 0; v < undir.length; v++)  {
			undir[v] = new Node(v); //oppretter noder
		}

		for(int i = 0; i < undir.length; i++) {
			//Node clone = clone(undir[i], map);
			for(Node nabo : nodes[i].getNeighbors()) { //henter nabo
				undir[nabo.getLabel()].addNeighbor(undir[i]);
			}
		}
		return new Graph(undir);
	}


	//Oppgave 1c
	public boolean isConnected(){
		Graph un = transformDirToUndir(); //gjør grafen uretta
		for(int i = 0; i < un.nodes.length; i++) {
			un.nodes[i].unvisit(); //markerer alle nodene ubesøkte
		}

		DFS(un.nodes[0]);

		for(int i = 0; i < un.nodes.length; i++) {
			if(un.nodes[i].isVisited() == false) {
				return false;
			}
		}
		return true;
	}

	//hjelpemetode for biggestComponent()
	private List<Node> DFS(Node n, List<Node> liste) {
		n.visit();
		liste.add(n);
		List<Node> naboer = n.getNeighbors();
		for(int i = 0; i < naboer.size(); i++) {
			Node n1 = naboer.get(i);
			if(n1.isVisited() == false) {
				DFS(n1, liste);
			}
		}
		return liste;
	}

	//Oppgave 1D
	public Graph biggestComponent() {
		List<Node> storst = new LinkedList<Node>();

		if(this.isConnected() == false) {

			for(Node n : nodes) {
				if(n.isVisited() == false) {
					List<Node> temp = new LinkedList<Node>();
					temp = DFS(n, temp);
					if(temp.size() > storst.size()) {
						storst = temp;
					}
				}
			}

		} else {
			System.out.println("Grafen har ikke komponenter, er en sammenhengde graf");
			return this;
		}


		Node [] storstKomponent = new Node[storst.size()];
		for(int i = 0; i < storst.size(); i++) {
			Node node = storst.get(i);
			storstKomponent[i] = node;
		}

		return new Graph(storstKomponent);
	}


	//Oppgave 1e
	public int[][] buildAdjacencyMatrix() {
		int [][] matrise = new int[nodes.length][nodes.length];
		for(int i = 0; i < matrise.length; i++) {
			for(int j = 0; j < matrise[i].length; j++) {
				for(Node n : nodes[i].getNeighbors()) {
					if(nodes[i].getNeighbors().contains(n)) {
						matrise[i][n.getLabel()] = 1;
					} else {
						matrise[i][j] = 0;
					}
				}
			}
		}
		return matrise; // for at koden skal kompilere
	}


	public static void main(String[] args) {
		Graph graph = buildExampleGraph();
		graph = buildRandomSparseGraph(11, 201909202359L);
		graph = buildRandomDirGraph(11, 201909202359L);
		graph.printNeighbors();
		System.out.println("");
		graph = buildRandomDenseGraph(15, 201909202359L);
		graph.printNeighbors();


	//MINE TESTER!!!!!
		System.out.println("****************");
		graph.isConnected();
		graph.numberOfComponents();
		Graph s = graph.transformDirToUndir();
		s.printNeighbors();
		Graph g = graph.biggestComponent();
		g.printNeighbors();

		int [][] m = graph.buildAdjacencyMatrix();
		for(int i = 0; i < m.length; i++) {
			for(int j = 0; j < m[i].length; j++) {
				System.out.println(m[i][j] + "\t");
			}
			System.out.println();
		}

	}
} //end of class
