import java.util.ArrayList;
class Task {
  int id, time, staff, earliestStart, latestStart;
  String name;

  ArrayList <Task> dependencies = new ArrayList<Task>(); //forgjengere
  ArrayList <Task> outEdges = new ArrayList<Task>();
  String state = "unvisited";
  int cntInEdges, cntOutEdges, slack;


  public Task(int id, String name, int time, int staff) {
    this.id = id;
    this.name = name;
    this.time = time;
    this.staff = staff;
  }

  public Task(int id) {
    this.id = id;
  }

  public String getName() {
		return name;
	}

  public int getId() {
    return id;
  }

  public int getStaff() {
    return staff;
  }

  public int getTime() {
    return time;
  }

  public boolean isCritical() {
    if(slack == 0) {
      return true;
    }
    return false;
  }

  public ArrayList<Task> getOutEdges() {
    return outEdges;
  }

  public void addOutEdges(Task t) {
    if (!outEdges.contains(t)) {
			outEdges.add(t);
			addOutEdges(t);
      cntOutEdges++;
		}
  }

  public ArrayList<Task> getDependencies() {
    return dependencies;
  }

  public void addDependencies(Task t) {
    if (!dependencies.contains(t)) {
			dependencies.add(t);
			addDependencies(t);
      cntInEdges++;
		}

  }

  public void setDetails(Task t) {
    name = t.name;
    time = t.time;
    staff = t.staff;
  }

  public String toString() {
    return "ID: " + getId() + "\t" + "Name: " + getName() + "\t" + "Time: " + getTime() + "\t" + "Staff: " + getStaff();
  }

}
