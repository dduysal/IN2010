************* -KOMPILERING OG BRUK- **********
  - Prosjekt.java,  Oblig.java og Task.java skal kompileres
  - Programmet kjøres slikt: java Oblig2 <filnavn.txt>

  - Programmet kompilerer og kjører. Men jeg får feil resultat fra calculateTime() når jeg printer ut latestStart og slack

************* -- ***************
  -

************* -KILDEBRUK- ***************
    - https://www.geeksforgeeks.org/topological-sorting/ (topSort)
    - https://algorithms.tutorialhorizon.com/graph-detect-cycle-in-a-directed-graph/ (finne sykel)
    - https://www.youtube.com/watch?v=AK7BuT5MgU0 (finne sykel)
    - Tok inspirasjon for løsningen av calculateTime() fra nettet, men KUN idee for hvordan jeg kunne løse den.
