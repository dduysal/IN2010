import java.util.*;
import java.io.*;

class Project {

  Task [] tasks;
  ArrayList<Task> cycleInDAG = new ArrayList<Task>();
  int runningTime;
  String cycleID = "";


  public Project(Task [] tasks) {
    this.tasks = tasks;
  }

  public void calculateTime() {
    LinkedList<Task> queue = new LinkedList<Task>(); //oppbevarer tasker som har ingen forgjengere
    Task task = null;

    for(int s = 1; s < tasks.length; s++) {
      tasks[s].earliestStart = 0;
      if(tasks[s].getDependencies().isEmpty()) {
        tasks[s].earliestStart = 0;
        queue.add(tasks[s]);
      }
    }

    while(!queue.isEmpty()) {
      task = queue.removeFirst();

      for(Task t1 : task.getOutEdges()) {
        t1.cntInEdges--;
        if(t1.earliestStart < (task.earliestStart + task.time)) {
          t1.earliestStart = task.earliestStart + task.time;
        }

        if(t1.earliestStart + t1.time > runningTime) {
          runningTime = t1.earliestStart + t1.time;
        }

        if(t1.cntInEdges == 0) {
          queue.add(t1);
        }

      }
    }

    queue = new LinkedList<Task>();
    Task [] sorted = TopoloicalSorting();

    for(int i = 1; i < sorted.length; i++) {
      sorted[i].latestStart = runningTime;

      if(sorted[i].cntOutEdges == 0) {
        sorted[i].latestStart = runningTime - sorted[i].time;
        queue.add(sorted[i]);
      }
    }

    while(!queue.isEmpty()) {
      Task task2 = queue.remove();

      for(Task t2 : task2.getDependencies()) {

        if(t2.latestStart > task2.latestStart - t2.time) {
          t2.latestStart = task2.latestStart - t2.time;
        }
        t2.cntOutEdges--;

        if(t2.cntOutEdges == 0) {
          queue.add(t2);
        }
      }
    }

    for(int t = 1; t < tasks.length; t++){
     tasks[t].slack = sorted[t].latestStart - tasks[t].earliestStart;
   }

  }


  //dfs
  public boolean cycle() {
    ArrayList<Integer> cycle = new ArrayList<Integer>();
    for(int i = 1; i < tasks.length; i++) {
      if(tasks[i].getDependencies().size() > 0) {
        if(hasCycle(tasks[i], cycle, "")) {
          return true;
        }
      }
    }
    return false;
  }

  //util
  public boolean hasCycle(Task t, ArrayList<Integer> cycle, String cycleTask) {
      if(t.state == "done") { //ferdig
        return false;
      }

      if(t.state == "visited") { //besøkt
        cycle.add(t.id);
        t.state = "done";
        cycleTask += t.id;

        cycleID = cycleTask;
        return true;
      }

      if(t.state == "unvisited") { //ikke besokt
        t.state = "visited";
        cycle.add(t.id);
        cycleTask += t.id;
        for(Task t1 : t.getOutEdges()) {
          if(hasCycle(t1, cycle, cycleTask)){
            return true;
          }
        }
        t.state = "done";
      }

    return false;
  }


  public int dfsTropo(int i, boolean[] visited, Task[] topSort, int v) {
    visited[i] = true;
    ArrayList<Task> edges = tasks[i].getDependencies();
    for(Task edge : edges) {
      if(visited[edge.getId()] == false) {
        v = dfsTropo(edge.getId(), visited, topSort, v);
      }
    }
    topSort[i] = tasks[v];
    return v-1;
  }


  public Task[] TopoloicalSorting() {
    int numberOfTask = tasks.length;
    boolean[] visited = new boolean[numberOfTask];
    Task[] topSort = new Task[numberOfTask];
    int index = numberOfTask -1;

    for(int u = 1; u < numberOfTask; u++) {
      if(visited[u] == false) {
        index = dfsTropo(u, visited, topSort, index);
      }
    }
    return topSort;
  }

  public void printTaskTime() {
    int currentMP = 0;
    for(int i = 0; i <= runningTime; i++) {
      boolean print = false;

      for(int t = 1; t < tasks.length; t++) {

        if(tasks[t].earliestStart == i) {
          if(!print) {
            System.out.println();
            System.out.println("Current time: " +i);
            print = true;
          }
          System.out.println("    Starting: " + tasks[t].id);
          currentMP += tasks[t].staff;
        }

        else if(tasks[t].earliestStart + tasks[t].time == i) {
          if(!print) {
            System.out.println("Current time: " +i);
            print = true;
          }
          System.out.println("    Finished: "+ tasks[t].id);
          currentMP -= tasks[t].staff;
        }
      }

    if(print) {
      System.out.println("    Current staff: "+currentMP + "\n");
    }
  }
    System.out.println("*** runningTime possible project execution is *** " + runningTime+ " ***" + "\n");

  }

  public void printCalculatedTime() {
    Task [] sorted = TopoloicalSorting();
    for (int i = 1; i < tasks.length; i++) {
      System.out.println("");
      System.out.println("Task " + tasks[i].id+ ":");
      System.out.println("    Name: "+ tasks[i].name);
      System.out.println("    Time: "+ tasks[i].time);
      System.out.println("    Manpower: "+ tasks[i].staff);
      System.out.println("    Slack: "+ tasks[i].slack);
      System.out.println("    Earliest Start: "+ tasks[i].earliestStart);
      System.out.println("    Latest Start: "+ sorted[i].latestStart);
      System.out.println("    Critical: "+ tasks[i].isCritical());
      System.out.print  ("    DEPENDECY:");

      if(tasks[i].getDependencies().isEmpty()) {
        System.out.println("NONE");
      }

      for (Task t : tasks[i].getDependencies()) {
        System.out.print(" "+ t.id);
      }
      System.out.println("");
    }
    System.out.print("******************************************\n");
  }

  public void printProject() {
    System.out.println("\n " + "******* INFORMATION *******");
    if(cycle()) {
      System.out.println("The project is not realizable and conatains a cycle");
      System.out.println("The tasks in the cycle: " + cycleID);

      for(int i = 1; i < tasks.length; i++) {
        System.out.println("");
        System.out.println("Task " + tasks[i].id+ ":");
        System.out.println("    Name: "+ tasks[i].name);
        System.out.println("    Time: "+ tasks[i].time);
        System.out.println("    Manpower: "+ tasks[i].staff);
        System.out.print  ("    DEPENDECY:");

        if(tasks[i].getDependencies().isEmpty()) {
          System.out.println("NONE");
        }

        for (Task t : tasks[i].getDependencies()) {
          System.out.print(" "+ t.id);
        }
        System.out.println("");
      }
    }

    else {
      printCalculatedTime();
      printTaskTime();

    }
  }


} //end of class
